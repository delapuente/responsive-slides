Building-Blocks
===============

Reusable components for Firefox OS

'style' and 'style_unastable' folders contain all Building Blocks from gaia's repo.
Feel free to use them, although we are using the word 'unestable' :) 
