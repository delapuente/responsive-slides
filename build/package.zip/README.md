# FirefoxOS responsive design

Here you have a complete slide application with responsive design using [Building Blocks](buildingfirefoxos.com).

Check it in [lodr.github.io/responsive-slides](http://lodr.github.io/responsive-slides).
